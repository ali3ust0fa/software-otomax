11/24/2014
=============
This driver is for Leka's USB UARTs.  This driver has been WHQL/HCK-certified on Windows 8.1.  The driver has been tested on
Windows XP/Vista/7/8/8.1. The version is 2.2.0.0.  

This zip file contains the following folders:

	x64	= contains the 64-bit driver for 64-bit systems.
	x86	= contains the 32-bit driver for 32-bit systems.	
	EXE	= contains the executable that will uninstall previous driver installations, install the new driver, and search for any USB devices attached to the system.

Revision History (Rev. 2.1 to 2.2):
 - WHQL/HCK certified driver for Windows 8.1.  Driver will also work on Windows XP, Vista, 7 including Win XP Embedded, Win 7 Embedded and Windows Server.


Revision History (Rev. 2.0 to 2.1):
 - WHQL/HCK certified driver for Windows 8.1.  Driver will also work on Windows XP, Vista, 7 including Win XP Embedded, Win 7 Embedded and Windows Server.
 - Minor fixes to the logic to pass Windows 8.1 HCK testing.

Revision History (Rev. 1.9 to 2.0):
 - WHQL/HCK certified driver for Windows 8.  Driver will also work on Windows XP, Vista, 7 including Win XP Embedded, Win 7 Embedded and Windows Server.
 - Minor fixes to the logic to pass Windows 8 HCK testing.	
